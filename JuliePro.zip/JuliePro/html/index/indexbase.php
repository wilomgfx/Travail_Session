<?php include '../view/header.php'; ?>
<?php require('../model/database.php'); ?>
<?php require('../model/utilisateur_db.php'); ?>
<?php require('../model/client_db.php'); ?>
<!--  Section PROMO
========================================== -->

<section>
    <div class="wrapper">
        <figure id="promo_image" class="grille_12">
            <img src="../../html/img/320.jpg" alt="320">

            <figcaption id="promo_caption">
                <h1>« Entrez dans le monde de JuliePro »</h1>
            </figcaption>
        </figure>
    </div>
</section>
<!--  FOOTER
========================================== -->
<?php include '../view/footer.php'; ?>
